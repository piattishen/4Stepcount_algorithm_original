import pathlib
import json
import hashlib
import warnings
from typing import Union
import numpy as np
import pandas as pd
from pandas.tseries.frequencies import to_offset
import actipy


def read(
    filepath: str,
    usecols: str = 'time,x,y,z',
    start_time: str = None,
    end_time: str = None,
    calibration_stdtol_min: float = None,
    sample_rate: float = None,
    resample_hz: str = 'uniform',
    start_first_complete_minute: bool = False,
    csv_start_row: int = None,
    csv_end_row: int = None,
    csv_time_format: str = None,
    csv_txyz_idxs: str = None,
    verbose: bool = True
):
    """
    Read and preprocess activity data from a file.

    This function reads activity data from various file formats, processes it using the `actipy` library,
    and returns the processed data along with metadata information.

    Parameters:
    - filepath (str): The path to the file containing activity data.
    - usecols (str, optional): A comma-separated string of column names to use when reading CSV files.
      Default is 'time,x,y,z'.
    - start_first_complete_minute (bool, optional): Whether to start data from the first complete minute.
      Uses 1 second tolerance. Default is False.
    - calibration_stdtol_min (float, optional): The minimum standard deviation tolerance for detecting stationary periods for calibration. If None,
      no minimum is applied. Default is None.
    - resample_hz (str, optional): The resampling frequency for the data. If 'uniform', it will use `sample_rate`
      and resample to ensure it is evenly spaced. Default is 'uniform'.
    - sample_rate (float, optional): The sample rate of the data. If None, it will be inferred. Default is None.
    - csv_start_row (int, optional): The file row number where the header is located (0-indexed).
      Rows before this are skipped. Only applies to CSV files. Default is None (header at row 0).
    - csv_end_row (int, optional): The file row number to stop reading at, inclusive (0-indexed).
      Only applies to CSV files. Default is None (read to the end).
    - csv_time_format (str, optional): Format string for parsing the time column (e.g., '%Y-%m-%d %H:%M:%S.%f').
      Only applies to CSV files. Default is None (auto-detect).
    - csv_txyz_idxs (str, optional): Column indices for time,x,y,z as comma-separated string (0-indexed, e.g., '0,1,2,3').
      Overrides usecols for CSV files. Default is None (use usecols/csv_txyz).
    - verbose (bool, optional): If True, enables verbose output during processing. Default is True.

    Returns:
    - tuple: A tuple containing:
        - data (pd.DataFrame): The processed activity data.
        - info (dict): A dictionary containing metadata information about the data.

    Raises:
    - ValueError: If the file format is unknown or unsupported.

    Example:
        data, info = read('activity_data.csv')
    """

    p = pathlib.Path(filepath)
    fsize = round(p.stat().st_size / (1024 * 1024), 1)
    ftype = p.suffix.lower()
    if ftype in (".gz", ".xz", ".lzma", ".bz2", ".zip"):  # if file is compressed, check the next extension
        ftype = pathlib.Path(p.stem).suffix.lower()

    if ftype in (".csv", ".pkl"):

        if ftype == ".csv":
            # Determine column names: either from indices or from usecols
            if csv_txyz_idxs is not None:
                # Parse and validate indices
                try:
                    tidx, xidx, yidx, zidx = map(int, csv_txyz_idxs.split(','))
                except ValueError:
                    raise ValueError(f"csv_txyz_idxs must be 4 comma-separated integers, got: '{csv_txyz_idxs}'")
                if any(i < 0 for i in [tidx, xidx, yidx, zidx]):
                    raise ValueError(f"csv_txyz_idxs must be non-negative integers, got: '{csv_txyz_idxs}'")
                # Read header to get column names at those indices
                # Skip csv_start_row rows to reach the actual header row
                header = pd.read_csv(filepath, nrows=0, skiprows=csv_start_row).columns.tolist()
                max_idx = max(tidx, xidx, yidx, zidx)
                if max_idx >= len(header):
                    raise ValueError(f"Column index {max_idx} out of range. CSV has {len(header)} columns.")
                tcol, xcol, ycol, zcol = header[tidx], header[xidx], header[yidx], header[zidx]
            else:
                tcol, xcol, ycol, zcol = usecols.split(',')

            # Validate csv_start_row and csv_end_row
            if csv_start_row is not None and csv_end_row is not None:
                if csv_end_row < csv_start_row:
                    raise ValueError(f"csv_end_row ({csv_end_row}) must be >= csv_start_row ({csv_start_row})")

            # skiprows: skip rows before the header if csv_start_row is specified
            # csv_start_row is 0-indexed file row where the header is located
            # skiprows=N skips rows 0 to N-1, making row N the header
            skiprows = csv_start_row

            # nrows: number of data rows to read
            # csv_end_row is file row to stop at (inclusive, 0-indexed)
            # Data rows are from (csv_start_row + 1) to csv_end_row
            if csv_end_row is None:
                nrows = None
            elif csv_start_row is None:
                nrows = csv_end_row  # rows 1 to csv_end_row = csv_end_row rows
            else:
                nrows = csv_end_row - csv_start_row  # rows (csv_start_row+1) to csv_end_row

            # Common read_csv kwargs
            read_kwargs = dict(
                usecols=[tcol, xcol, ycol, zcol],
                dtype={xcol: 'f4', ycol: 'f4', zcol: 'f4'},
                skiprows=skiprows,
                nrows=nrows,
            )

            if csv_time_format is None:
                # Auto-detect datetime format
                read_kwargs['parse_dates'] = [tcol]
                read_kwargs['index_col'] = tcol
                data = pd.read_csv(filepath, **read_kwargs)
            else:
                # Use specified datetime format
                data = pd.read_csv(filepath, **read_kwargs)
                data[tcol] = pd.to_datetime(data[tcol], format=csv_time_format)
                data = data.set_index(tcol)

            # rename to standard names
            data = data.rename(columns={xcol: 'x', ycol: 'y', zcol: 'z'})
            data.index.name = 'time'

        elif ftype == ".pkl":
            data = pd.read_pickle(filepath)

        else:
            raise ValueError(f"Unknown file format: {ftype}")

        if sample_rate in (None, False):
            freq = infer_freq(data.index)
            sample_rate = int(np.round(pd.Timedelta('1s') / freq))

        # Quick fix: Drop duplicate indices. TODO: Maybe should be handled by actipy.
        data = data[~data.index.duplicated(keep='first')]

        data, info = actipy.process(
            data, sample_rate,
            lowpass_hz=None,
            calibrate_gravity=True,
            calibrate_gravity_kwargs={'stdtol_min': calibration_stdtol_min},
            detect_nonwear=True,
            resample_hz=resample_hz,
            start_first_complete_minute=start_first_complete_minute,
            verbose=verbose,
        )

        info.update({
            "Filename": filepath,
            "Device": ftype,
            "Filesize(MB)": fsize,
            "SampleRate": sample_rate,
        })

    elif ftype in (".cwa", ".gt3x", ".bin"):

        if csv_start_row is not None or csv_end_row is not None or csv_time_format is not None or csv_txyz_idxs is not None:
            warnings.warn("--csv-* options are only supported for CSV files. Ignoring.")

        data, info = actipy.read_device(
            filepath,
            lowpass_hz=None,
            calibrate_gravity=True,
            calibrate_gravity_kwargs={'stdtol_min': calibration_stdtol_min},
            detect_nonwear=True,
            resample_hz=resample_hz,
            start_first_complete_minute=start_first_complete_minute,
            verbose=verbose,
        )

    else:
        raise ValueError(f"Unknown file format: {ftype}")

    if 'ResampleRate' not in info:
        info['ResampleRate'] = info['SampleRate']

    # Trim the data if start/end times are specified
    if start_time is not None:
        data = data.loc[start_time:]
    if end_time is not None:
        data = data.loc[:end_time]

    # Update wear stats
    info.update(calculate_wear_stats(data))

    return data, info


def calculate_wear_stats(data: pd.DataFrame):
    """
    Calculate wear time and related information from raw accelerometer data.

    Parameters:
    - data (pd.DataFrame): A pandas DataFrame of raw accelerometer data with columns 'x', 'y', 'z' and a DatetimeIndex.

    Returns:
    - dict: A dictionary containing various wear time stats.

    Example:
        info = calculate_wear_stats(data)
    """

    TIME_FORMAT = "%Y-%m-%d %H:%M:%S"

    n_data = len(data)

    if n_data == 0:
        start_time = None
        end_time = None
        wear_start_time = None
        wear_end_time = None
        nonwear_duration = 0.0
        wear_duration = 0.0
        covers24hok = 0

    else:
        na = data.isna().any(axis=1)  # TODO: check na only on x,y,z cols?
        dt = infer_freq(data.index).total_seconds()
        start_time = data.index[0].strftime(TIME_FORMAT)
        end_time = data.index[-1].strftime(TIME_FORMAT)
        wear_start_time = data.first_valid_index()
        if wear_start_time is not None:
            wear_start_time = wear_start_time.strftime(TIME_FORMAT)
        wear_end_time = data.last_valid_index()
        if wear_end_time is not None:
            wear_end_time = wear_end_time.strftime(TIME_FORMAT)
        nonwear_duration = na.sum() * dt / (60 * 60 * 24)
        wear_duration = n_data * dt / (60 * 60 * 24) - nonwear_duration 
        coverage = (~na).groupby(na.index.hour).mean()
        covers24hok = int(len(coverage) == 24 and coverage.min() >= 0.01)

    return {
        'StartTime': start_time,
        'EndTime': end_time,
        'WearStartTime': wear_start_time,
        'WearEndTime': wear_end_time,
        'WearTime(days)': wear_duration,
        'NonwearTime(days)': nonwear_duration,
        'Covers24hOK': covers24hok
    }


def calculate_daily_wear_stats(data: pd.DataFrame):
    """
    Calculate daily wear time statistics from raw accelerometer data.

    Parameters:
    - data (pd.DataFrame): A pandas DataFrame of raw accelerometer data with columns 'x', 'y', 'z' and a DatetimeIndex.

    Returns:
    - pd.DataFrame: A DataFrame with dates as index and daily wear statistics as columns:
        - 'WearTime(hours)': Total wear time in hours

    Example:
        daily_wear_stats = calculate_daily_wear_stats(data)
    """

    if len(data) == 0:
        return pd.DataFrame()

    # Identify non-wear periods (NaN in any of x,y,z columns)
    na = data.isna().any(axis=1)
    dt = infer_freq(data.index).total_seconds()

    # Group by date
    date_groups = data.groupby(data.index.date)

    results = []

    for date, day_data in date_groups:
        day_na = na.loc[day_data.index]
        n_samples = len(day_data)

        if n_samples == 0:
            # Skip empty days
            continue

        # Calculate wear time
        nonwear_samples = day_na.sum()
        wear_samples = n_samples - nonwear_samples

        # Convert to hours
        wear_hours = wear_samples * dt / 3600

        results.append({
            'Date': pd.to_datetime(date),
            'WearTime(hours)': round(wear_hours, 2)
        })

    if not results:
        return pd.DataFrame()

    # Create DataFrame and set date as index
    daily_stats = pd.DataFrame(results)
    daily_stats.set_index('Date', inplace=True)
    daily_stats.index.name = 'Date'

    return daily_stats


def flag_wear_below_days(
    x: Union[pd.Series, pd.DataFrame],
    min_wear: str = '12H'
):
    """
    Set days containing less than the specified minimum wear time (`min_wear`) to NaN.

    Parameters:
    - x (pd.Series or pd.DataFrame): A pandas Series or DataFrame with a DatetimeIndex representing time series data.
    - min_wear (str): A string representing the minimum wear time required per day (e.g., '8H' for 8 hours).

    Returns:
    - pd.Series or pd.DataFrame: A pandas Series or DataFrame with days having less than `min_wear` of valid data set to NaN.

    Example:
        # Exclude days with less than 12 hours of valid data
        series = exclude_wear_below_days(series, min_wear='12H')
    """
    if len(x) == 0:
        print("No data to exclude")
        return x

    min_wear = pd.Timedelta(min_wear)
    dt = infer_freq(x.index)
    ok = x.notna()
    if isinstance(ok, pd.DataFrame):
        ok = ok.all(axis=1)
    ok = (
        ok
        .groupby(x.index.date)
        .sum() * dt
        >= min_wear
    )
    # keep ok days, rest is set to NaN
    x = x.copy()  # make a copy to avoid modifying the original data
    x[np.isin(x.index.date, ok[~ok].index)] = np.nan
    return x


def drop_first_last_days(
    x: Union[pd.Series, pd.DataFrame],
    first_or_last='both'
):
    """
    Drop the first day, last day, or both from a time series.

    Parameters:
    - x (pd.Series or pd.DataFrame): A pandas Series or DataFrame with a DatetimeIndex representing time series data.
    - first_or_last (str, optional): A string indicating which days to drop. Options are 'first', 'last', or 'both'. Default is 'both'.

    Returns:
    - pd.Series or pd.DataFrame: A pandas Series or DataFrame with the values of the specified days dropped.

    Example:
        # Drop the first day from the series
        series = drop_first_last_days(series, first_or_last='first')
    """
    if len(x) == 0:
        print("No data to drop")
        return x

    if first_or_last == 'first':
        x = x[x.index.date != x.index.date[0]]
    elif first_or_last == 'last':
        x = x[x.index.date != x.index.date[-1]]
    elif first_or_last == 'both':
        x = x[(x.index.date != x.index.date[0]) & (x.index.date != x.index.date[-1])]
    return x


def impute_missing(
    data: pd.DataFrame,
    extrapolate=True,
    skip_full_missing_days=True
):
    """
    Impute missing values in the given DataFrame using a multi-step approach.

    This function fills in missing values in a time series DataFrame by applying a series of 
    imputation strategies. It can also extrapolate data to ensure full 24-hour coverage and 
    optionally skip days that are entirely missing.

    Parameters:
    - data (pd.DataFrame): The DataFrame containing the time series data to be imputed. 
      The index should be a datetime index.
    - extrapolate (bool, optional): Whether to extrapolate data beyond the start and end times 
      to ensure full 24-hour coverage. Defaults to True.
    - skip_full_missing_days (bool, optional): Whether to skip days that have all missing values. 
      Defaults to True.

    Returns:
    - pd.DataFrame: The DataFrame with missing values imputed.

    Notes:
    - The imputation process involves three steps in the following order:
        1. Imputation using the same day of the week.
        2. Imputation within weekdays or weekends.
        3. Imputation using all other days.
    - The granularity of the imputation is 5 minutes. 
    - If `extrapolate` is True, the function will attempt to fill in data beyond the start and end times, so that 
      the first and last day have full 24-hour coverage.
    - If `skip_full_missing_days` is True, days with all missing values will be excluded from the imputation process.
    """
    def fillna(subframe):
        if isinstance(subframe, pd.Series):
            x = subframe.to_numpy()
            nan = np.isnan(x)
            nanlen = len(x[nan])
            if 0 < nanlen < len(x):  # check x contains a NaN and is not all NaN
                x[nan] = np.nanmean(x)
                return x  # will be cast back to a Series automatically
            else:
                return subframe

    def impute(data):
        return (
            data
            # first attempt imputation using same day of week
            .groupby([data.index.weekday, data.index.hour, data.index.minute // 5])
            .transform(fillna)
            # then try within weekday/weekend
            .groupby([data.index.weekday >= 5, data.index.hour, data.index.minute // 5])
            .transform(fillna)
            # finally, use all other days
            .groupby([data.index.hour, data.index.minute // 5])
            .transform(fillna)
        )

    if skip_full_missing_days:
        # Compute dates where ALL values are NaN (across all columns if DataFrame)
        # Handle both Series (1D) and DataFrame (2D) cases
        if isinstance(data, pd.DataFrame):
            # For DataFrame: check if all columns are NaN per row, then group by date
            row_all_na = data.isna().all(axis=1)
        else:
            # For Series: just check if each value is NaN
            row_all_na = data.isna()
        full_na_dates = row_all_na.groupby(data.index.date).all()
        full_na_dates = full_na_dates[full_na_dates].index  # Extract dates where entire day is NaN

    if extrapolate:  # extrapolate beyond start/end times to have full 24h
        freq = infer_freq(data.index)
        if pd.isna(freq):
            warnings.warn("Cannot infer frequency, using 1s")
            freq = pd.Timedelta('1s')
        freq = to_offset(freq)
        data = data.reindex(
            pd.date_range(
                # Note that at exactly 00:00:00, the floor('D') and ceil('D') will be the same
                data.index[0].floor('D'),
                data.index[-1].ceil('D'),
                freq=freq,
                inclusive='left',
                name='time',
            ),
            method='nearest',
            tolerance=pd.Timedelta('1m'),
            limit=1)

    data = impute(data)

    if skip_full_missing_days:
        # Set rows for fully-missing dates back to NaN
        mask = np.isin(data.index.date, full_na_dates)
        data.loc[mask] = np.nan

    return data


def impute_days(
    x: pd.Series,
    method='mean'
):
    """
    Impute missing values for data with a daily resolution.

    The imputation is performed in three steps: first by the same day of the
    week, then by weekdays or weekends, and finally by the entire series.

    Parameters:
    - x (pd.Series): A pandas Series at a daily resolution level.
    - method (str, optional): The imputation method to use. Options are 'mean' or 'median'. 
      Defaults to 'mean'.

    Returns:
    - pd.Series: A pandas Series with missing days imputed.

    Raises:
    - ValueError: If an unknown imputation method is specified.

    Notes:
    - The imputation process involves three steps in the following order:
        1. Imputation using the same day of the week.
        2. Imputation within weekdays or weekends.
        3. Imputation using the entire series.
    - If the entire Series is missing, it will be returned as is.
    """
    if x.isna().all():
        return x

    def fillna(x):
        if method == 'mean':
            return x.fillna(x.mean())
        elif method == 'median':
            return x.fillna(x.median())
        else:
            raise ValueError(f"Unknown method: {method}")

    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='Mean of empty slice')
        return (
            x
            .groupby(x.index.weekday).transform(fillna)
            .groupby(x.index.weekday >= 5).transform(fillna)
            .transform(fillna)
        )


def infer_freq(t):
    """ Like pd.infer_freq but more forgiving """
    tdiff = t.to_series().diff()
    q1, q3 = tdiff.quantile([0.25, 0.75])
    tdiff = tdiff[(q1 <= tdiff) & (tdiff <= q3)]
    freq = tdiff.mean()
    freq = pd.Timedelta(freq)
    return freq


def resolve_path(path):
    """ Return parent folder, file name and file extension """
    p = pathlib.Path(path)
    extension = p.suffixes[0]
    filename = p.name.rsplit(extension)[0]
    dirname = p.parent
    return dirname, filename, extension


def md5(fname):
    hash_md5 = hashlib.md5()
    with open(fname, "rb") as f:
        for chunk in iter(lambda: f.read(4096), b""):
            hash_md5.update(chunk)
    return hash_md5.hexdigest()


class NpEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if pd.isnull(obj):  # handles pandas NAType
            return np.nan
        return json.JSONEncoder.default(self, obj)


def nanint(x):
    if np.isnan(x):
        return x
    return int(x)
